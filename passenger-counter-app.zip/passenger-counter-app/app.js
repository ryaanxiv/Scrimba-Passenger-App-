var counterSys = document.getElementById('counter-sys');
var previousEntries = document.getElementById('previous-entries');
var counter = 0

function incrementing() {
    counter+=1;
    counterSys.textContent = counter;
}
function savingEntries(){
    var entrySave = counterSys.textContent;
    previousEntries.innerText +=' '+ entrySave+'; ';
    counterSys.innerText=0;
}